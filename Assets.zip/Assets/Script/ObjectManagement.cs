using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ObjectManagement : MonoBehaviour
{
    private Renderer objRender;
    private Vector3 objSize;
    private TextMesh txt;
    private TextMesh txt2;
    // Start is called before the first frame update
    void Start()
    {
        objRender = gameObject.transform.Find("Preview").GetComponent<Renderer>();
        txt = gameObject.transform.Find("Text").GetComponent<TextMesh>();
        txt2 = gameObject.transform.Find("Info").GetComponent<TextMesh>();
        objSize = GetComponent<BoxCollider>().bounds.size;
        objRender.material.color = new Color(0f, 0f, 0.7f, 0.4f);
    }

    // Update is called once per frame
    void Update()
    {
        
        txt.text = Mathf.Round(objSize.x * gameObject.transform.localScale.x * 100) / 100 + "M x "
            + Mathf.Round(objSize.y * gameObject.transform.localScale.y * 100) / 100
            + "M x " + Mathf.Round(objSize.z * gameObject.transform.localScale.z  * 100) / 100 + "M";

        txt2.text = Mathf.Round(objSize.x * gameObject.transform.localScale.x * 100) / 100 + "M x "
            + Mathf.Round(objSize.y * gameObject.transform.localScale.y * 100) / 100
            + "M x " + Mathf.Round(objSize.z * gameObject.transform.localScale.z * 100) / 100 + "M";
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "ARObject")
        {
            Debug.Log("Triggered");
            objRender.material.color = new Color(0.7f, 0f, 0f, 0.4f);
        }
        
        //pain color red
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "ARObject")
        {
            Debug.Log("Triggered");
            objRender.material.color = new Color(0f, 0f, 0.7f, 0.4f);
        }
    }
}
