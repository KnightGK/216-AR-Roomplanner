using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShowFurniture : MonoBehaviour
{
    private GameObject[] furnitures;

    private Toggle tggl;
    private bool isOn;
    // Start is called before the first frame update
    void Start()
    {
        tggl = GetComponent<Toggle>();
        tggl.onValueChanged.AddListener(delegate { changeState(); });

    }

    // Update is called once per frame
    void Update()
    {
    }
    void changeState()
    {
        isOn = tggl.isOn;
        if(isOn == true)
        {
            //do switch
            furnitures = GameObject.FindGameObjectsWithTag("ARObject");
            foreach(GameObject furniture in furnitures)
            {
                furniture.transform.Find("model").gameObject.SetActive(true);
                furniture.transform.Find("Preview").gameObject.SetActive(false);
            }

        }
        else
        {
            //do switch
            furnitures = GameObject.FindGameObjectsWithTag("ARObject");
            foreach (GameObject furniture in furnitures)
            {
                furniture.transform.Find("model").gameObject.SetActive(false);
                furniture.transform.Find("Preview").gameObject.SetActive(true);
            }
        }
    }


}
