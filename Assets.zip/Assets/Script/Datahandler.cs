using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Datahandler : MonoBehaviour
{
    public GameObject furniture;

    [SerializeField]
    private ButtonManager buttonPrefab;
    [SerializeField]
    private GameObject buttonContainer;
    [SerializeField]
    private List<item> _items;

    private int current_id = 0;

    private static Datahandler _instance;
    public static Datahandler Instance
    {
        get
        {
            if(_instance == null)
            {
                _instance = FindObjectOfType<Datahandler>();
            }
            return _instance;
        }
    }
    private void Start()
    {
        LoadItems();
        CreateButton();
    }
    void LoadItems()
    {
        var items_obj = Resources.LoadAll("Items", typeof(item));
        foreach (var _item in items_obj)
        {
            _items.Add(_item as item);
        }
    }

    void CreateButton()
    {
        foreach (item i in _items)
        {
            ButtonManager b = Instantiate(buttonPrefab, buttonContainer.transform);
            b.ItemId = current_id;
            b.buttonText = i.Name;
            current_id++;
        }
    }

    public void SetFurniture(int id)
    {
        furniture = _items[id].itemPrefab;
    }

    public GameObject GetFurniture()
    {
        return furniture;
    }
}
