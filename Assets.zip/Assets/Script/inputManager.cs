using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.EventSystems;
using UnityEngine.XR.Interaction.Toolkit.AR;

public class inputManager : ARBaseGestureInteractable
{
    [SerializeField]
    private Camera arCamera;
    [SerializeField]
    private ARRaycastManager _raycastManager;
    [SerializeField]
    private GameObject crosshair;

    List<ARRaycastHit> _hits = new List<ARRaycastHit>();

    private Touch touch;
    private Pose pose;
    // Start is called before the first frame update
    void Start()
    {
    }

    protected override bool CanStartManipulationForGesture(TapGesture gesture)
    {
        if (gesture.targetObject == null)
            return true;
        return false;
    }

    protected override void OnEndManipulation(TapGesture gesture)
    {
        if (gesture.isCanceled)
            return;
        if (gesture.targetObject != null || isPointerOverUI(gesture))
            return;
        if (GestureTransformationUtility.Raycast(gesture.startPosition, _hits, UnityEngine.XR.ARSubsystems.TrackableType.PlaneEstimated))
        {

            GameObject placeObj = Instantiate(Datahandler.Instance.GetFurniture(), pose.position, pose.rotation);

            var anchorObject = new GameObject("PlacementAnchro");
            anchorObject.transform.position = pose.position;
            anchorObject.transform.rotation = pose.rotation;
            placeObj.transform.parent = anchorObject.transform;
        }

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        CrosshairCalculation();


    }

    bool isPointerOverUI(TapGesture touch)
    {
        PointerEventData eventData = new PointerEventData(EventSystem.current);
        eventData.position = new Vector2(touch.startPosition.x, touch.startPosition.y);
        List<RaycastResult> results = new List<RaycastResult>();

        EventSystem.current.RaycastAll(eventData, results);
        return results.Count > 0;
    }

    private RaycastHit hit;
    void CrosshairCalculation()
    {
        Vector3 origin = arCamera.ViewportToScreenPoint(new Vector3(0.5f, 0.5f, 0));
        Ray ray = arCamera.ScreenPointToRay(origin);

        if (GestureTransformationUtility.Raycast(origin, _hits, UnityEngine.XR.ARSubsystems.TrackableType.PlaneEstimated))
        {
            pose = _hits[0].pose;
            crosshair.transform.position = pose.position;
            crosshair.transform.eulerAngles = new Vector3(90, 0, 0);
        }
        else if (Physics.Raycast(ray, out hit))
        {
            crosshair.transform.position = hit.point;
            crosshair.transform.up = hit.normal;
        }
    }
}
